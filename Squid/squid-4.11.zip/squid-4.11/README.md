# Microservise squid 4.11
* Argenis Ochoa Gonzalez

1. This now execute

docker-compose up -d

2. The microservice will restart again and again



docker-compose down

(Fix)  :)

chmod 777 squid -Rv
docker-compose up -d

(Ready)
:)

3. Configure your browser proxy

ip port 3128


;)
